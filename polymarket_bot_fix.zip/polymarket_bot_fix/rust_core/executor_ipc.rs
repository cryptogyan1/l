use anyhow::{anyhow, Result};
use log::{debug, info, warn};
use serde::{Deserialize, Serialize};
use std::io::{BufRead, BufReader, Write};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::sync::{Arc, Mutex};

/// Command sent to Python executor
#[derive(Debug, Serialize)]
#[serde(tag = "action")]
pub enum ExecutorCommand {
    #[serde(rename = "initialize")]
    Initialize { config: ExecutorConfig },
    
    #[serde(rename = "submit_order")]
    SubmitOrder { order: OrderCommand },
    
    #[serde(rename = "get_orderbook")]
    GetOrderbook { token_id: String },
    
    #[serde(rename = "cancel_order")]
    CancelOrder { order_id: String },
    
    #[serde(rename = "get_balance")]
    GetBalance,
    
    #[serde(rename = "ping")]
    Ping,
}

/// Configuration for executor
#[derive(Debug, Serialize)]
pub struct ExecutorConfig {
    pub private_key: String,
    pub chain_id: u64,
    pub clob_url: String,
}

/// Order command to send to executor
#[derive(Debug, Serialize)]
pub struct OrderCommand {
    pub token_id: String,
    pub side: String,  // "BUY" or "SELL"
    pub price: f64,    // Price in USD
    pub size: f64,     // Size in contracts
}

/// Response from executor
#[derive(Debug, Deserialize)]
pub struct ExecutorResponse {
    pub success: bool,
    #[serde(default)]
    pub message: Option<String>,
    #[serde(default)]
    pub error: Option<String>,
    #[serde(default)]
    pub order_id: Option<String>,
    #[serde(default)]
    pub eoa_address: Option<String>,
}

/// IPC client to communicate with Python executor
pub struct ExecutorClient {
    child: Arc<Mutex<Child>>,
    stdin: Arc<Mutex<ChildStdin>>,
    stdout: Arc<Mutex<BufReader<ChildStdout>>>,
}

impl ExecutorClient {
    /// Start the Python executor process
    pub fn start(python_script_path: &str) -> Result<Self> {
        info!("🚀 Starting Python executor: {}", python_script_path);
        
        let mut child = Command::new("python3")
            .arg(python_script_path)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::inherit())
            .spawn()
            .map_err(|e| anyhow!("Failed to start executor: {}", e))?;
        
        let stdin = child.stdin.take().ok_or_else(|| anyhow!("Failed to open stdin"))?;
        let stdout = child.stdout.take().ok_or_else(|| anyhow!("Failed to open stdout"))?;
        
        info!("✅ Python executor started (PID: {})", child.id());
        
        Ok(Self {
            child: Arc::new(Mutex::new(child)),
            stdin: Arc::new(Mutex::new(stdin)),
            stdout: Arc::new(Mutex::new(BufReader::new(stdout))),
        })
    }
    
    /// Send a command and wait for response
    pub fn send_command(&self, command: ExecutorCommand) -> Result<ExecutorResponse> {
        debug!("Sending command: {:?}", command);
        
        // Serialize command to JSON
        let json = serde_json::to_string(&command)?;
        
        // Write to stdin
        {
            let mut stdin = self.stdin.lock().unwrap();
            writeln!(stdin, "{}", json)?;
            stdin.flush()?;
        }
        
        // Read response from stdout
        let response_line = {
            let mut stdout = self.stdout.lock().unwrap();
            let mut line = String::new();
            stdout.read_line(&mut line)?;
            line
        };
        
        // Parse response
        let response: ExecutorResponse = serde_json::from_str(&response_line)
            .map_err(|e| anyhow!("Failed to parse response: {} - Response: {}", e, response_line))?;
        
        if !response.success {
            if let Some(ref err) = response.error {
                warn!("Executor error: {}", err);
                return Err(anyhow!("Executor error: {}", err));
            }
        }
        
        Ok(response)
    }
    
    /// Initialize the executor with credentials
    pub fn initialize(&self, config: ExecutorConfig) -> Result<String> {
        info!("Initializing Python executor...");
        
        let response = self.send_command(ExecutorCommand::Initialize { config })?;
        
        let eoa_address = response.eoa_address
            .ok_or_else(|| anyhow!("No EOA address in response"))?;
        
        info!("✅ Executor initialized with EOA: {}", eoa_address);
        
        Ok(eoa_address)
    }
    
    /// Submit an order
    pub fn submit_order(&self, order: OrderCommand) -> Result<String> {
        info!(
            "📤 Submitting {} order for token {}",
            order.side, &order.token_id[..16]
        );
        
        let response = self.send_command(ExecutorCommand::SubmitOrder { order })?;
        
        let order_id = response.order_id
            .ok_or_else(|| anyhow!("No order ID in response"))?;
        
        info!("✅ Order submitted: {}", order_id);
        
        Ok(order_id)
    }
    
    /// Ping the executor to check it's alive
    pub fn ping(&self) -> Result<()> {
        let response = self.send_command(ExecutorCommand::Ping)?;
        
        if response.success {
            debug!("Executor ping OK");
            Ok(())
        } else {
            Err(anyhow!("Executor ping failed"))
        }
    }
}

impl Drop for ExecutorClient {
    fn drop(&mut self) {
        info!("Shutting down Python executor...");
        if let Ok(mut child) = self.child.lock() {
            let _ = child.kill();
        }
    }
}
