use crate::client::PolymarketClient;
use crate::config::TradingConfig;
use crate::domain::ArbitrageOpportunity;
use crate::executor::errors::ExecutionError;
use crate::executor_ipc::{ExecutorClient, OrderCommand};
use anyhow::Result;
use log::{info, warn};
use std::sync::Arc;

pub struct Trader {
    api: Arc<PolymarketClient>,
    executor: Arc<ExecutorClient>,
    config: TradingConfig,
}

impl Trader {
    pub fn new(
        api: Arc<PolymarketClient>,
        executor: Arc<ExecutorClient>,
        config: TradingConfig,
    ) -> Self {
        Self {
            api,
            executor,
            config,
        }
    }

    pub async fn execute_arbitrage(&self, opp: &ArbitrageOpportunity) -> Result<(), ExecutionError> {
        info!("🎯 Executing arbitrage opportunity:");
        info!("   Buy:  {} @ ${:.4}", opp.buy_token, opp.buy_price);
        info!("   Sell: {} @ ${:.4}", opp.sell_token, opp.sell_price);
        info!("   Expected profit: ${:.2}", opp.profit);

        // Check if in read-only mode
        let read_only = std::env::var("READ_ONLY")
            .unwrap_or_else(|_| "false".to_string())
            .parse()
            .unwrap_or(false);

        if read_only {
            info!("📝 [READ-ONLY] Would execute arbitrage");
            return Ok(());
        }

        // Calculate size based on config
        let size = self.calculate_position_size(opp)?;

        // Submit BUY order via Python executor
        let buy_order = OrderCommand {
            token_id: opp.buy_token.clone(),
            side: "BUY".to_string(),
            price: opp.buy_price,
            size,
        };

        match self.executor.submit_order(buy_order) {
            Ok(buy_order_id) => {
                info!("✅ Buy order placed: {}", buy_order_id);
            }
            Err(e) => {
                warn!("❌ Buy order failed: {}", e);
                return Err(ExecutionError::OrderFailed(e.to_string()));
            }
        }

        // Submit SELL order via Python executor
        let sell_order = OrderCommand {
            token_id: opp.sell_token.clone(),
            side: "SELL".to_string(),
            price: opp.sell_price,
            size,
        };

        match self.executor.submit_order(sell_order) {
            Ok(sell_order_id) => {
                info!("✅ Sell order placed: {}", sell_order_id);
            }
            Err(e) => {
                warn!("❌ Sell order failed: {}", e);
                return Err(ExecutionError::OrderFailed(e.to_string()));
            }
        }

        info!("✅ Arbitrage executed successfully!");
        Ok(())
    }

    fn calculate_position_size(&self, opp: &ArbitrageOpportunity) -> Result<f64, ExecutionError> {
        // Simple fixed size for now
        // In production, this would consider:
        // - Available balance
        // - Position limits
        // - Market depth
        // - Risk parameters
        
        let size = self.config.position_size as f64;
        
        info!("📊 Position size: {} contracts", size);
        
        Ok(size)
    }
}
