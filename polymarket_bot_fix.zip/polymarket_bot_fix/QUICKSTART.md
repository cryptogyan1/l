# 🚀 QUICK START - 5 MINUTES TO RUNNING BOT

## ⚡ TL;DR - Run These Commands

```bash
# 1. Go to fix directory
cd ~/polymarket_bot_fix/scripts

# 2. Run the fix (does everything automatically)
./apply_fix.sh

# 3. Configure your wallet
cd ~/l-main
cp ~/polymarket_bot_fix/.env.template .env
nano .env  # Edit with your PRIVATE_KEY and PROXY_WALLET

# 4. Run diagnostics
~/polymarket_bot_fix/scripts/diagnose.sh

# 5. Start the bot
./run_bot.sh
```

## 📋 Prerequisites

- Ubuntu/Linux system
- Python 3.8+
- Rust/Cargo installed
- Polygon RPC URL
- Private key and proxy wallet address

## 🎯 Step-by-Step

### Step 1: Extract the Fix (If you haven't)

```bash
cd ~
unzip polymarket_bot_fix.zip
```

### Step 2: Apply the Fix

```bash
cd ~/polymarket_bot_fix/scripts
chmod +x apply_fix.sh
./apply_fix.sh
```

**What this does**:
- ✅ Backs up your original bot
- ✅ Installs Python dependencies
- ✅ Adds IPC communication
- ✅ Creates startup scripts

**Time**: ~2 minutes

### Step 3: Configure Your Wallet

```bash
cd ~/l-main
cp ~/polymarket_bot_fix/.env.template .env
nano .env
```

**Edit these lines**:
```bash
PRIVATE_KEY=0xyour_actual_private_key_here
PROXY_WALLET=0xyour_wallet_address_here
RPC_URL=https://polygon-rpc.com  # or your RPC
READ_ONLY=true  # Keep true for testing!
```

**Save**: `Ctrl+O`, `Enter`, `Ctrl+X`

### Step 4: Run Diagnostics

```bash
~/polymarket_bot_fix/scripts/diagnose.sh
```

**Expected output**:
```
✅ PASS - All checks passed!
```

If any checks fail, fix them before continuing.

### Step 5: Test Python Executor

```bash
cd ~/polymarket_bot_fix/python_executor
source venv/bin/activate
echo '{"action":"ping"}' | python executor.py
```

**Expected output**:
```json
{"success": true, "message": "pong"}
```

### Step 6: Run the Bot!

```bash
cd ~/l-main
./run_bot.sh
```

**You should see**:
```
🚀 Starting Polymarket Arbitrage Bot (Rust + Python)
   Architecture: Rust Strategy + Python Executor

🐍 Starting Python executor...
[EXECUTOR] Polymarket Executor started
✅ Python executor ready
   EOA: 0xYourAddress...

✅ Executor ping successful
✅ Bot initialized successfully!
🔍 Starting main arbitrage loop...
```

## 🎮 What Happens Next

### In READ_ONLY Mode (Recommended First)
- Bot detects arbitrage opportunities
- Logs what orders it WOULD place
- No real money at risk
- Perfect for testing

### When You're Ready for Live Trading
```bash
# Stop the bot (Ctrl+C)

# Edit .env
nano ~/l-main/.env
# Change: READ_ONLY=false

# Restart
./run_bot.sh
```

## 📊 Monitoring

### Watch Rust Logs
Main terminal shows strategy decisions

### Watch Python Logs
```bash
tail -f ~/polymarket_bot_fix/python_executor/executor.log
```

### Check for Opportunities
```bash
grep "arbitrage opportunity" ~/l-main/bot.log
```

## 🐛 Troubleshooting

### Error: "Failed to start executor"
```bash
chmod +x ~/polymarket_bot_fix/python_executor/executor.py
```

### Error: "Module not found: py_clob_client"
```bash
cd ~/polymarket_bot_fix/python_executor
source venv/bin/activate
pip install -r requirements.txt
```

### Error: "401 Unauthorized"
Check your `PRIVATE_KEY` in `.env` - make sure it's the EOA private key, not proxy wallet

### Build Errors
```bash
cd ~/l-main
cargo clean
cargo build --release
```

## 🎯 Success Indicators

✅ **Bot started successfully** if you see:
```
✅ Python executor ready
✅ Bot initialized successfully!
🔍 Starting main arbitrage loop...
```

✅ **Bot is working** if you see:
```
✅ ETH Market: eth-updown-15m-...
✅ BTC Market: btc-updown-15m-...
```

✅ **Opportunities detected** if you see:
```
🔔 Found 1 arbitrage opportunity(ies)!
📋 Processing opportunity 1 of 1
```

## 📞 Still Stuck?

1. Run diagnostics: `~/polymarket_bot_fix/scripts/diagnose.sh`
2. Check logs: `cat ~/polymarket_bot_fix/python_executor/executor.log`
3. Read detailed docs: `cat ~/polymarket_bot_fix/README.md`

## ⚠️ Safety Reminders

1. ✅ Test in READ_ONLY mode first
2. ✅ Start with small position sizes
3. ✅ Monitor the bot actively
4. ✅ Never share your private key
5. ✅ Keep backups of your configuration

---

**That's it!** Your bot should now work without 401 errors. 🎉
