#!/bin/bash

# ==============================================================================
# Polymarket Bot Fix - Rust + Python Architecture
# ==============================================================================
# This script transforms your pure Rust bot into a hybrid architecture where:
# - Rust handles logic, strategy, and decision-making
# - Python executor handles all CLOB API calls using official SDK
# ==============================================================================

set -e  # Exit on error

echo "🔧 Polymarket Bot Fix Script"
echo "================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
FIXED_BOT_DIR="$(dirname "$SCRIPT_DIR")"
ORIGINAL_BOT_DIR="$HOME/l-main"

echo "📂 Directories:"
echo "   Original bot: $ORIGINAL_BOT_DIR"
echo "   Fixed files:  $FIXED_BOT_DIR"
echo ""

# ==============================================================================
# Step 1: Backup original bot
# ==============================================================================
echo -e "${YELLOW}[Step 1/7]${NC} Backing up original bot..."

if [ -d "${ORIGINAL_BOT_DIR}.backup" ]; then
    echo "   Backup already exists, skipping..."
else
    cp -r "$ORIGINAL_BOT_DIR" "${ORIGINAL_BOT_DIR}.backup"
    echo -e "${GREEN}✅ Backup created${NC}"
fi
echo ""

# ==============================================================================
# Step 2: Install Python dependencies
# ==============================================================================
echo -e "${YELLOW}[Step 2/7]${NC} Installing Python dependencies..."

cd "$FIXED_BOT_DIR/python_executor"

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "   Creating Python virtual environment..."
    python3 -m venv venv
fi

echo "   Activating virtual environment..."
source venv/bin/activate

echo "   Installing py-clob-client and dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

echo -e "${GREEN}✅ Python dependencies installed${NC}"
echo ""

# ==============================================================================
# Step 3: Add IPC module to Rust
# ==============================================================================
echo -e "${YELLOW}[Step 3/7]${NC} Adding IPC module to Rust bot..."

# Create executor_ipc module in src
cp "$FIXED_BOT_DIR/rust_core/executor_ipc.rs" "$ORIGINAL_BOT_DIR/src/execution/"

# Check if executor_ipc is already in mod.rs
if ! grep -q "pub mod executor_ipc" "$ORIGINAL_BOT_DIR/src/execution/mod.rs"; then
    echo "pub mod executor_ipc;" >> "$ORIGINAL_BOT_DIR/src/execution/mod.rs"
fi

echo -e "${GREEN}✅ IPC module added${NC}"
echo ""

# ==============================================================================
# Step 4: Update Cargo.toml dependencies
# ==============================================================================
echo -e "${YELLOW}[Step 4/7]${NC} Updating Cargo.toml..."

cd "$ORIGINAL_BOT_DIR"

# Backup Cargo.toml
cp Cargo.toml Cargo.toml.bak

# Add serde_json if not present (needed for IPC)
if ! grep -q 'serde_json' Cargo.toml; then
    cat >> Cargo.toml << 'EOF'

# IPC communication
serde_json = "1.0"
EOF
fi

echo -e "${GREEN}✅ Cargo.toml updated${NC}"
echo ""

# ==============================================================================
# Step 5: Modify main.rs to use executor
# ==============================================================================
echo -e "${YELLOW}[Step 5/7]${NC} Modifying main.rs to use Python executor..."

cat > "$ORIGINAL_BOT_DIR/src/main_ipc.rs" << 'EOF'
use polymarket_15m_arbitrage_bot::*;

use anyhow::Result;
use clap::Parser;
use config::{Args, Config};
use execution::executor_ipc::{ExecutorClient, ExecutorConfig};
use log::{info, warn};
use std::sync::Arc;

use cache::PriceCache;
use client::PolymarketClient;
use execution::Trader;
use monitor::MarketMonitor;
use strategy::ArbitrageDetector;

fn current_15m_period() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs();
    (now / 900) * 900
}

#[tokio::main]
async fn main() -> Result<()> {
    dotenv::dotenv().ok();

    if std::env::var("RUST_LOG").is_err() {
        std::env::set_var("RUST_LOG", "info");
    }
    env_logger::init();

    info!("🚀 Starting Polymarket Arbitrage Bot (Rust + Python)");
    info!("   Architecture: Rust Strategy + Python Executor");
    info!("");

    let args = Args::parse();
    let config = Config::load(&args.config)?;

    // ===============================
    // LOAD CREDENTIALS FROM .ENV
    // ===============================
    let private_key = std::env::var("PRIVATE_KEY").expect("PRIVATE_KEY missing in .env file");
    let _proxy_wallet = std::env::var("PROXY_WALLET").expect("PROXY_WALLET missing in .env file");
    let clob_url = config.polymarket.clob_api_url.clone();

    // ===============================
    // START PYTHON EXECUTOR
    // ===============================
    info!("🐍 Starting Python executor...");
    
    let executor_path = std::env::var("EXECUTOR_PATH")
        .unwrap_or_else(|_| "../python_executor/executor.py".to_string());
    
    let executor = Arc::new(ExecutorClient::start(&executor_path)?);
    
    // Initialize executor with credentials
    let executor_config = ExecutorConfig {
        private_key: private_key.clone(),
        chain_id: 137,
        clob_url: clob_url.clone(),
    };
    
    let eoa_address = executor.initialize(executor_config)?;
    info!("✅ Python executor ready");
    info!("   EOA: {}", eoa_address);
    info!("");

    // Test connection
    executor.ping()?;
    info!("✅ Executor ping successful");
    info!("");

    // ===============================
    // API CLIENT (Read-only for market data)
    // ===============================
    let api_key = std::env::var("POLY_API_KEY").ok();
    let api_secret = std::env::var("POLY_API_SECRET").ok();
    let api_passphrase = std::env::var("POLY_API_PASSPHRASE").ok();

    let api = Arc::new(PolymarketClient::new(
        config.polymarket.gamma_api_url.clone(),
        config.polymarket.clob_api_url.clone(),
        api_key.unwrap_or_default(),
        api_secret.unwrap_or_default(),
        api_passphrase.unwrap_or_default(),
        true,  // Read-only for Rust side
        Arc::new(()),  // Dummy clob client - we're not using it
    ));

    // ===============================
    // CORE OBJECTS
    // ===============================
    let _price_cache = PriceCache::new();
    let detector = Arc::new(ArbitrageDetector::new(config.trading.min_profit_threshold));
    
    let trader = Arc::new(Trader::new(
        api.clone(),
        executor.clone(),
        config.trading.clone(),
    ));

    let mut current_period = current_15m_period();

    info!("✅ Bot initialized successfully!");
    info!("🔍 Starting main arbitrage loop...");
    info!("");

    // ===============================
    // MAIN LOOP
    // ===============================
    loop {
        info!("🔍 Discovering current 15m markets...");

        let (eth_market, btc_market) = match discover_markets(&api).await {
            Ok(markets) => markets,
            Err(e) => {
                warn!("Failed to discover markets: {}", e);
                tokio::time::sleep(std::time::Duration::from_secs(60)).await;
                continue;
            }
        };

        info!("✅ ETH Market: {}", eth_market.slug);
        info!("✅ BTC Market: {}", btc_market.slug);

        let monitor = MarketMonitor::new(
            api.clone(),
            eth_market,
            btc_market,
            config.trading.check_interval_ms,
        );

        let monitor_handle = tokio::spawn({
            let detector = detector.clone();
            let trader = trader.clone();

            async move {
                monitor
                    .start_monitoring(move |snapshot| {
                        let detector = detector.clone();
                        let trader = trader.clone();

                        async move {
                            let opportunities = detector.detect_opportunities(&snapshot);

                            if !opportunities.is_empty() {
                                info!("🔔 Found {} arbitrage opportunity(ies)!", opportunities.len());
                            }

                            for (i, o) in opportunities.iter().enumerate() {
                                info!("📋 Processing opportunity {} of {}", i + 1, opportunities.len());

                                match trader.execute_arbitrage(&o).await {
                                    Ok(_) => {
                                        info!("✅ Opportunity {} handled successfully", i + 1);
                                    }
                                    Err(e) => {
                                        warn!("❌ Opportunity {} failed: {}", i + 1, e);
                                    }
                                }
                            }
                        }
                    })
                    .await;
            }
        });

        loop {
            tokio::time::sleep(std::time::Duration::from_secs(1)).await;
            let new_period = current_15m_period();

            if new_period != current_period {
                info!("⏰ 15m rollover — restarting monitor");
                current_period = new_period;
                monitor_handle.abort();
                break;
            }
        }
    }
}

async fn discover_markets(api: &PolymarketClient) -> Result<(domain::Market, domain::Market)> {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)?
        .as_secs();

    let mut seen = std::collections::HashSet::new();

    let eth = discover_market(api, "ETH", "eth", now, &mut seen).await?;
    seen.insert(eth.condition_id.clone());

    let btc = discover_market(api, "BTC", "btc", now, &mut seen).await?;

    Ok((eth, btc))
}

async fn discover_market(
    api: &PolymarketClient,
    name: &str,
    prefix: &str,
    now: u64,
    seen: &mut std::collections::HashSet<String>,
) -> Result<domain::Market> {
    let base = (now / 900) * 900;

    for i in 0..=3 {
        let ts = base - i * 900;
        let slug = format!("{}-updown-15m-{}", prefix, ts);

        if let Ok(market) = api.get_market_by_slug(&slug).await {
            if !seen.contains(&market.condition_id) && market.active {
                info!("Found {} market: {}", name, market.slug);
                return Ok(market);
            }
        }
    }

    anyhow::bail!("No active {} market found", name)
}
EOF

echo -e "${GREEN}✅ main_ipc.rs created${NC}"
echo ""

# ==============================================================================
# Step 6: Create modified trader.rs
# ==============================================================================
echo -e "${YELLOW}[Step 6/7]${NC} Creating modified trader.rs..."

cat > "$ORIGINAL_BOT_DIR/src/execution/trader_ipc.rs" << 'EOF'
use crate::client::PolymarketClient;
use crate::config::TradingConfig;
use crate::domain::ArbitrageOpportunity;
use crate::execution::errors::ExecutionError;
use crate::execution::executor_ipc::{ExecutorClient, OrderCommand};
use anyhow::Result;
use log::{info, warn};
use std::sync::Arc;

pub struct Trader {
    api: Arc<PolymarketClient>,
    executor: Arc<ExecutorClient>,
    config: TradingConfig,
}

impl Trader {
    pub fn new(
        api: Arc<PolymarketClient>,
        executor: Arc<ExecutorClient>,
        config: TradingConfig,
    ) -> Self {
        Self {
            api,
            executor,
            config,
        }
    }

    pub async fn execute_arbitrage(&self, opp: &ArbitrageOpportunity) -> Result<(), ExecutionError> {
        info!("🎯 Executing arbitrage opportunity:");
        info!("   Buy:  {} @ ${:.4}", &opp.buy_token[..16], opp.buy_price);
        info!("   Sell: {} @ ${:.4}", &opp.sell_token[..16], opp.sell_price);
        info!("   Expected profit: ${:.2}", opp.profit);

        let read_only = std::env::var("READ_ONLY")
            .unwrap_or_else(|_| "false".to_string())
            .parse()
            .unwrap_or(false);

        if read_only {
            info!("📝 [READ-ONLY] Would execute arbitrage");
            return Ok(());
        }

        let size = self.calculate_position_size(opp)?;

        // Submit BUY order
        let buy_order = OrderCommand {
            token_id: opp.buy_token.clone(),
            side: "BUY".to_string(),
            price: opp.buy_price,
            size,
        };

        match self.executor.submit_order(buy_order) {
            Ok(buy_order_id) => {
                info!("✅ Buy order placed: {}", buy_order_id);
            }
            Err(e) => {
                warn!("❌ Buy order failed: {}", e);
                return Err(ExecutionError::OrderFailed(e.to_string()));
            }
        }

        // Submit SELL order
        let sell_order = OrderCommand {
            token_id: opp.sell_token.clone(),
            side: "SELL".to_string(),
            price: opp.sell_price,
            size,
        };

        match self.executor.submit_order(sell_order) {
            Ok(sell_order_id) => {
                info!("✅ Sell order placed: {}", sell_order_id);
            }
            Err(e) => {
                warn!("❌ Sell order failed: {}", e);
                return Err(ExecutionError::OrderFailed(e.to_string()));
            }
        }

        info!("✅ Arbitrage executed successfully!");
        Ok(())
    }

    fn calculate_position_size(&self, _opp: &ArbitrageOpportunity) -> Result<f64, ExecutionError> {
        let size = self.config.position_size as f64;
        info!("📊 Position size: {} contracts", size);
        Ok(size)
    }
}
EOF

echo -e "${GREEN}✅ trader_ipc.rs created${NC}"
echo ""

# ==============================================================================
# Step 7: Create startup script
# ==============================================================================
echo -e "${YELLOW}[Step 7/7]${NC} Creating startup script..."

cat > "$ORIGINAL_BOT_DIR/run_bot.sh" << 'EOF'
#!/bin/bash

# Polymarket Bot Startup Script
# Runs the Rust bot with Python executor

set -e

echo "🚀 Starting Polymarket Arbitrage Bot"
echo "====================================="
echo ""

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Check if .env exists
if [ ! -f "$SCRIPT_DIR/.env" ]; then
    echo "❌ Error: .env file not found"
    echo "Please create a .env file with:"
    echo "  PRIVATE_KEY=your_private_key"
    echo "  PROXY_WALLET=your_proxy_wallet"
    echo "  RPC_URL=your_rpc_url"
    echo "  READ_ONLY=true  # Set to false for live trading"
    exit 1
fi

# Source .env
source "$SCRIPT_DIR/.env"

echo "📋 Configuration:"
echo "   RPC_URL: ${RPC_URL:0:30}..."
echo "   PROXY_WALLET: $PROXY_WALLET"
echo "   READ_ONLY: ${READ_ONLY:-false}"
echo ""

# Build Rust bot
echo "🔨 Building Rust bot..."
cd "$SCRIPT_DIR"
cargo build --release --quiet

if [ $? -ne 0 ]; then
    echo "❌ Build failed"
    exit 1
fi

echo "✅ Build successful"
echo ""

# Run the bot
echo "🏃 Starting bot..."
echo ""

cargo run --release --bin polymarket_15m_arbitrage_bot

EOF

chmod +x "$ORIGINAL_BOT_DIR/run_bot.sh"

echo -e "${GREEN}✅ Startup script created${NC}"
echo ""

# ==============================================================================
# Summary
# ==============================================================================
echo "================================"
echo -e "${GREEN}✅ Fix Complete!${NC}"
echo "================================"
echo ""
echo "📋 What was done:"
echo "   1. ✅ Backed up original bot"
echo "   2. ✅ Installed Python dependencies (py-clob-client)"
echo "   3. ✅ Added IPC module to Rust"
echo "   4. ✅ Updated Cargo.toml"
echo "   5. ✅ Created modified main.rs with executor"
echo "   6. ✅ Created modified trader.rs"
echo "   7. ✅ Created startup script"
echo ""
echo "🏗️  Architecture:"
echo "   ┌──────────────────┐"
echo "   │   RUST CORE      │ ← Strategy, Logic, Decisions"
echo "   │   (Fast & Safe)  │"
echo "   └────────┬─────────┘"
echo "            │ JSON/IPC"
echo "            ▼"
echo "   ┌──────────────────┐"
echo "   │ PYTHON EXECUTOR  │ ← API Calls, Order Signing"
echo "   │ (Official SDK)   │"
echo "   └────────┬─────────┘"
echo "            │"
echo "            ▼"
echo "     Polymarket CLOB"
echo ""
echo "📝 Next steps:"
echo ""
echo "1. Update your .env file in $ORIGINAL_BOT_DIR:"
echo "   PRIVATE_KEY=0x..."
echo "   PROXY_WALLET=0x..."
echo "   RPC_URL=https://..."
echo "   READ_ONLY=true  # Set false for live trading"
echo ""
echo "2. Test the Python executor:"
echo "   cd $FIXED_BOT_DIR/python_executor"
echo "   source venv/bin/activate"
echo "   echo '{\"action\":\"ping\"}' | python executor.py"
echo ""
echo "3. Run the bot:"
echo "   cd $ORIGINAL_BOT_DIR"
echo "   ./run_bot.sh"
echo ""
echo "🔍 Troubleshooting:"
echo "   - Check executor.log for Python errors"
echo "   - Check RUST_LOG=debug for detailed Rust logs"
echo "   - Verify API credentials are correct"
echo ""
echo "📚 Documentation:"
echo "   - Polymarket docs: https://docs.polymarket.com"
echo "   - py-clob-client: https://github.com/Polymarket/py-clob-client"
echo ""

deactivate 2>/dev/null || true

echo -e "${GREEN}Done!${NC} 🎉"
