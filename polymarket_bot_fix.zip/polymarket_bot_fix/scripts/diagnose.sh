#!/bin/bash

# ==============================================================================
# Polymarket Bot Diagnostic Script
# ==============================================================================
# Run this after applying the fix to verify everything is working
# ==============================================================================

set -e

echo "🔍 Polymarket Bot Diagnostics"
echo "============================="
echo ""

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

ERRORS=0
WARNINGS=0

check() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ PASS${NC}"
        return 0
    else
        echo -e "${RED}❌ FAIL${NC}"
        ((ERRORS++))
        return 1
    fi
}

warn() {
    echo -e "${YELLOW}⚠️  WARNING: $1${NC}"
    ((WARNINGS++))
}

# ==============================================================================
# Check 1: Original bot backup exists
# ==============================================================================
echo -n "📂 Checking backup exists... "
if [ -d "$HOME/l-main.backup" ]; then
    check
else
    echo -e "${RED}❌ FAIL - No backup found${NC}"
    ((ERRORS++))
fi

# ==============================================================================
# Check 2: Python executor exists
# ==============================================================================
echo -n "🐍 Checking Python executor... "
test -f "$HOME/fixed_bot/python_executor/executor.py"
check

# ==============================================================================
# Check 3: Python virtual environment
# ==============================================================================
echo -n "🔧 Checking Python venv... "
test -d "$HOME/fixed_bot/python_executor/venv"
check

# ==============================================================================
# Check 4: Python dependencies installed
# ==============================================================================
echo -n "📦 Checking py-clob-client... "
source "$HOME/fixed_bot/python_executor/venv/bin/activate" 2>/dev/null
python3 -c "import py_clob_client" 2>/dev/null
check

# ==============================================================================
# Check 5: IPC module exists in Rust
# ==============================================================================
echo -n "🦀 Checking IPC module... "
test -f "$HOME/l-main/src/execution/executor_ipc.rs"
check

# ==============================================================================
# Check 6: Modified files exist
# ==============================================================================
echo -n "📝 Checking modified files... "
test -f "$HOME/l-main/src/main_ipc.rs"
check

# ==============================================================================
# Check 7: Startup script exists
# ==============================================================================
echo -n "🚀 Checking startup script... "
test -f "$HOME/l-main/run_bot.sh" && test -x "$HOME/l-main/run_bot.sh"
check

# ==============================================================================
# Check 8: .env file exists
# ==============================================================================
echo -n "⚙️  Checking .env file... "
if [ -f "$HOME/l-main/.env" ]; then
    check
else
    echo -e "${RED}❌ FAIL - .env file missing${NC}"
    ((ERRORS++))
    warn "Create .env file with PRIVATE_KEY, PROXY_WALLET, RPC_URL"
fi

# ==============================================================================
# Check 9: Required env vars
# ==============================================================================
if [ -f "$HOME/l-main/.env" ]; then
    source "$HOME/l-main/.env" 2>/dev/null
    
    echo -n "🔑 Checking PRIVATE_KEY... "
    if [ -n "$PRIVATE_KEY" ]; then
        check
    else
        echo -e "${RED}❌ FAIL - PRIVATE_KEY not set${NC}"
        ((ERRORS++))
    fi
    
    echo -n "🏦 Checking PROXY_WALLET... "
    if [ -n "$PROXY_WALLET" ]; then
        check
    else
        echo -e "${RED}❌ FAIL - PROXY_WALLET not set${NC}"
        ((ERRORS++))
    fi
    
    echo -n "🌐 Checking RPC_URL... "
    if [ -n "$RPC_URL" ]; then
        check
    else
        echo -e "${RED}❌ FAIL - RPC_URL not set${NC}"
        ((ERRORS++))
    fi
fi

# ==============================================================================
# Check 10: Test Python executor
# ==============================================================================
echo -n "🧪 Testing Python executor (ping)... "
RESPONSE=$(echo '{"action":"ping"}' | timeout 5 python3 "$HOME/fixed_bot/python_executor/executor.py" 2>/dev/null | head -1)
if echo "$RESPONSE" | grep -q '"success".*true'; then
    check
else
    echo -e "${RED}❌ FAIL - Executor not responding correctly${NC}"
    echo "   Response: $RESPONSE"
    ((ERRORS++))
fi

# ==============================================================================
# Check 11: Rust build test
# ==============================================================================
echo -n "🔨 Testing Rust build... "
cd "$HOME/l-main"
if cargo build --release --quiet 2>&1 | grep -q "error"; then
    echo -e "${RED}❌ FAIL - Build has errors${NC}"
    ((ERRORS++))
    warn "Run 'cargo build' to see detailed errors"
else
    check
fi

deactivate 2>/dev/null || true

# ==============================================================================
# Summary
# ==============================================================================
echo ""
echo "============================="
echo "📊 Diagnostic Summary"
echo "============================="

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}✅ All checks passed!${NC}"
    echo ""
    echo "Your bot is ready to run:"
    echo "  cd ~/l-main"
    echo "  ./run_bot.sh"
    echo ""
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}⚠️  All checks passed with $WARNINGS warning(s)${NC}"
    echo "You can run the bot, but review warnings above."
    echo ""
else
    echo -e "${RED}❌ $ERRORS error(s), $WARNINGS warning(s)${NC}"
    echo ""
    echo "Fix the errors above before running the bot."
    echo ""
fi

# ==============================================================================
# Next Steps
# ==============================================================================
if [ $ERRORS -eq 0 ]; then
    echo "📝 Next steps:"
    echo ""
    echo "1. Review your configuration:"
    echo "   cat ~/l-main/.env"
    echo ""
    echo "2. Test in READ_ONLY mode first:"
    echo "   # In .env, set: READ_ONLY=true"
    echo ""
    echo "3. Run the bot:"
    echo "   cd ~/l-main"
    echo "   ./run_bot.sh"
    echo ""
    echo "4. Monitor logs:"
    echo "   # Rust logs in terminal"
    echo "   # Python logs in: ~/fixed_bot/python_executor/executor.log"
    echo ""
fi

exit $ERRORS
