# ✅ Installation Checklist

Print this or keep it open while you install the fix!

---

## 📋 PRE-INSTALLATION

- [ ] I have my Rust bot in `~/l-main` directory
- [ ] I have my `PRIVATE_KEY` ready
- [ ] I have my `PROXY_WALLET` address ready
- [ ] I have a Polygon RPC URL ready
- [ ] I have Python 3.8+ installed: `python3 --version`
- [ ] I have cargo/rust installed: `cargo --version`

---

## 🔧 INSTALLATION

### Step 1: Extract Package
```bash
cd ~
# Extract polymarket_bot_fix.zip if not done
```
- [ ] Package extracted to `~/polymarket_bot_fix/`

### Step 2: Run Fix Script
```bash
cd ~/polymarket_bot_fix/scripts
./apply_fix.sh
```

Watch for these checkmarks:
- [ ] ✅ Backup created
- [ ] ✅ Python dependencies installed
- [ ] ✅ IPC module added
- [ ] ✅ Cargo.toml updated
- [ ] ✅ main_ipc.rs created
- [ ] ✅ trader_ipc.rs created
- [ ] ✅ Startup script created

### Step 3: Configure Environment
```bash
cd ~/l-main
cp ~/polymarket_bot_fix/.env.template .env
nano .env
```

Edit these values:
- [ ] `PRIVATE_KEY=0x...` (your EOA private key)
- [ ] `PROXY_WALLET=0x...` (your wallet address)
- [ ] `RPC_URL=https://...` (Polygon RPC)
- [ ] `READ_ONLY=true` (for testing)

Save: `Ctrl+O`, `Enter`, `Ctrl+X`

### Step 4: Run Diagnostics
```bash
~/polymarket_bot_fix/scripts/diagnose.sh
```

Verify all checks pass:
- [ ] ✅ Backup exists
- [ ] ✅ Python executor exists
- [ ] ✅ Python venv created
- [ ] ✅ py-clob-client installed
- [ ] ✅ IPC module added to Rust
- [ ] ✅ Modified files exist
- [ ] ✅ Startup script exists
- [ ] ✅ .env file exists
- [ ] ✅ PRIVATE_KEY set
- [ ] ✅ PROXY_WALLET set
- [ ] ✅ RPC_URL set
- [ ] ✅ Executor responds to ping
- [ ] ✅ Rust builds successfully

---

## 🧪 TESTING

### Test 1: Python Executor
```bash
cd ~/polymarket_bot_fix/python_executor
source venv/bin/activate
echo '{"action":"ping"}' | python executor.py
```

Expected output:
```json
{"success": true, "message": "pong"}
```
- [ ] ✅ Executor responds correctly

### Test 2: Initialize Executor
```bash
cat << 'EOF' | python executor.py
{"action":"initialize","config":{"private_key":"YOUR_KEY","chain_id":137,"clob_url":"https://clob.polymarket.com"}}
EOF
```

Expected:
```json
{"success": true, "message": "Executor initialized", "eoa_address": "0x..."}
```
- [ ] ✅ Executor initializes correctly

### Test 3: Build Rust Bot
```bash
cd ~/l-main
cargo build --release
```
- [ ] ✅ Build completes without errors

---

## 🚀 LAUNCH

### First Run (Read-Only Mode)
```bash
cd ~/l-main
READ_ONLY=true ./run_bot.sh
```

You should see:
```
🚀 Starting Polymarket Arbitrage Bot (Rust + Python)
🐍 Starting Python executor...
[EXECUTOR] Polymarket Executor started
✅ Python executor ready
   EOA: 0xYourAddress...
✅ Executor ping successful
✅ Bot initialized successfully!
🔍 Starting main arbitrage loop...
```

Check these:
- [ ] ✅ Bot starts without errors
- [ ] ✅ Python executor starts
- [ ] ✅ Markets discovered
- [ ] ✅ Monitoring loop running
- [ ] ✅ No 401 errors!

### Monitor Logs

Terminal 1 (Rust logs):
```bash
cd ~/l-main
./run_bot.sh
```

Terminal 2 (Python logs):
```bash
tail -f ~/polymarket_bot_fix/python_executor/executor.log
```

- [ ] ✅ Rust logs show opportunities
- [ ] ✅ Python logs show order submissions
- [ ] ✅ No error messages

---

## 🎯 GOING LIVE

When you're ready for live trading:

1. Stop the bot: `Ctrl+C`

2. Edit config:
```bash
nano ~/l-main/.env
# Change: READ_ONLY=false
```

3. Restart:
```bash
./run_bot.sh
```

4. Monitor actively:
- [ ] ✅ Orders executing
- [ ] ✅ Balances updating
- [ ] ✅ No errors
- [ ] ✅ Profits accumulating

---

## 🐛 TROUBLESHOOTING

If something goes wrong:

### Issue: Can't find executor
```bash
chmod +x ~/polymarket_bot_fix/python_executor/executor.py
```
- [ ] Fixed

### Issue: Module not found
```bash
cd ~/polymarket_bot_fix/python_executor
source venv/bin/activate
pip install -r requirements.txt
```
- [ ] Fixed

### Issue: 401 errors
1. Check PRIVATE_KEY in .env
2. Verify it's EOA key (not proxy)
3. Ensure 0x prefix
- [ ] Fixed

### Issue: Build errors
```bash
cd ~/l-main
cargo clean
cargo build --release
```
- [ ] Fixed

---

## 📊 VERIFICATION

After 24 hours of running:

- [ ] No 401 errors in logs
- [ ] Orders executing successfully
- [ ] Arbitrage opportunities detected
- [ ] Python executor stable
- [ ] Rust bot stable
- [ ] Profits/losses as expected

---

## 🎉 SUCCESS!

When all items are checked:

- [x] Installation complete
- [x] Configuration correct
- [x] Tests passing
- [x] Bot running
- [x] Orders executing
- [x] No errors

**You're done! Your bot is fixed and profitable!** 🚀

---

## 📞 SUPPORT

If you get stuck:

1. **Re-run diagnostics**:
   ```bash
   ~/polymarket_bot_fix/scripts/diagnose.sh
   ```

2. **Check logs**:
   - Rust: Terminal output
   - Python: `executor.log`

3. **Read docs**:
   - Quick: `QUICKSTART.md`
   - Full: `README.md`
   - Technical: `CHANGES.md`

4. **Analyze issues**:
   ```bash
   ~/polymarket_bot_fix/scripts/analyze_current_bot.sh
   ```

---

## 🎯 QUICK REFERENCE

```bash
# Apply fix
cd ~/polymarket_bot_fix/scripts && ./apply_fix.sh

# Configure
cd ~/l-main && nano .env

# Diagnose
~/polymarket_bot_fix/scripts/diagnose.sh

# Test executor
cd ~/polymarket_bot_fix/python_executor && source venv/bin/activate
echo '{"action":"ping"}' | python executor.py

# Build bot
cd ~/l-main && cargo build --release

# Run bot
cd ~/l-main && ./run_bot.sh

# Watch logs
tail -f ~/polymarket_bot_fix/python_executor/executor.log
```

---

**Good luck! Happy trading!** 💰
