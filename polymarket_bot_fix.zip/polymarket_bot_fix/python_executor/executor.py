#!/usr/bin/env python3
"""
Polymarket Order Executor - Python Service
Uses official py-clob-client SDK for authenticated API calls
Receives commands from Rust core via JSON stdin
"""

import json
import sys
import os
import logging
from typing import Dict, Any, Optional
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import OrderArgs, OrderType
from py_clob_client.order_builder.constants import BUY, SELL
from eth_account import Account
from decimal import Decimal

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='[EXECUTOR] %(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stderr),  # Log to stderr so stdout is clean for IPC
        logging.FileHandler('executor.log')
    ]
)
logger = logging.getLogger(__name__)


class PolymarketExecutor:
    """Executes orders on Polymarket using official SDK"""
    
    def __init__(self):
        self.client: Optional[ClobClient] = None
        self.initialized = False
        
    def initialize(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Initialize the CLOB client with credentials"""
        try:
            private_key = config.get('private_key')
            chain_id = config.get('chain_id', 137)  # Polygon
            host = config.get('clob_url', 'https://clob.polymarket.com')
            
            if not private_key:
                raise ValueError("private_key is required")
            
            # Ensure private key has 0x prefix
            if not private_key.startswith('0x'):
                private_key = '0x' + private_key
            
            logger.info(f"Initializing CLOB client...")
            logger.info(f"Chain ID: {chain_id}")
            logger.info(f"Host: {host}")
            
            # Create account from private key
            account = Account.from_key(private_key)
            logger.info(f"EOA Address: {account.address}")
            
            # Initialize client - it will auto-create/derive API keys
            self.client = ClobClient(
                host=host,
                key=private_key,
                chain_id=chain_id
            )
            
            logger.info("✅ CLOB client initialized successfully")
            
            # Derive API credentials
            creds = self.client.derive_api_key()
            logger.info(f"API Key: {creds.api_key[:8]}...")
            
            self.initialized = True
            
            return {
                'success': True,
                'message': 'Executor initialized',
                'eoa_address': account.address
            }
            
        except Exception as e:
            logger.error(f"Failed to initialize: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def submit_order(self, order_data: Dict[str, Any]) -> Dict[str, Any]:
        """Submit an order to Polymarket CLOB"""
        if not self.initialized or not self.client:
            return {
                'success': False,
                'error': 'Executor not initialized'
            }
        
        try:
            # Extract order parameters
            token_id = order_data['token_id']
            side = order_data['side']  # 'BUY' or 'SELL'
            price = float(order_data['price'])  # Price in USD (e.g., 0.55)
            size = float(order_data['size'])    # Size in contracts (e.g., 100)
            
            logger.info(f"📤 Submitting order:")
            logger.info(f"   Token ID: {token_id}")
            logger.info(f"   Side: {side}")
            logger.info(f"   Price: ${price:.4f}")
            logger.info(f"   Size: {size} contracts")
            
            # Create order args
            order_args = OrderArgs(
                token_id=token_id,
                price=price,
                size=size,
                side=BUY if side == 'BUY' else SELL,
                fee_rate_bps=0  # Polymarket typically uses 0 for makers
            )
            
            # Submit order (SDK handles signing and authentication)
            signed_order = self.client.create_order(order_args)
            resp = self.client.post_order(signed_order, OrderType.GTC)
            
            logger.info(f"✅ Order submitted successfully!")
            logger.info(f"   Order ID: {resp.get('orderID', 'N/A')}")
            
            return {
                'success': True,
                'order_id': resp.get('orderID'),
                'response': resp
            }
            
        except Exception as e:
            logger.error(f"❌ Order submission failed: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_orderbook(self, token_id: str) -> Dict[str, Any]:
        """Fetch orderbook for a token"""
        if not self.initialized or not self.client:
            return {
                'success': False,
                'error': 'Executor not initialized'
            }
        
        try:
            book = self.client.get_order_book(token_id)
            return {
                'success': True,
                'orderbook': book
            }
        except Exception as e:
            logger.error(f"Failed to fetch orderbook: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """Cancel an order"""
        if not self.initialized or not self.client:
            return {
                'success': False,
                'error': 'Executor not initialized'
            }
        
        try:
            resp = self.client.cancel(order_id)
            logger.info(f"✅ Order {order_id} cancelled")
            return {
                'success': True,
                'response': resp
            }
        except Exception as e:
            logger.error(f"Failed to cancel order: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_balance(self) -> Dict[str, Any]:
        """Get USDC balance"""
        if not self.initialized or not self.client:
            return {
                'success': False,
                'error': 'Executor not initialized'
            }
        
        try:
            # Get balance from client
            balance = self.client.get_balance()
            return {
                'success': True,
                'balance': balance
            }
        except Exception as e:
            logger.error(f"Failed to get balance: {e}")
            return {
                'success': False,
                'error': str(e)
            }


def main():
    """Main loop - read JSON commands from stdin, execute, write responses to stdout"""
    executor = PolymarketExecutor()
    
    logger.info("🚀 Polymarket Executor started")
    logger.info("Waiting for commands from Rust core...")
    
    # Read commands line by line from stdin
    for line in sys.stdin:
        try:
            line = line.strip()
            if not line:
                continue
            
            # Parse command
            command = json.loads(line)
            action = command.get('action')
            
            logger.info(f"📨 Received command: {action}")
            
            # Route to appropriate handler
            if action == 'initialize':
                response = executor.initialize(command.get('config', {}))
            elif action == 'submit_order':
                response = executor.submit_order(command.get('order', {}))
            elif action == 'get_orderbook':
                response = executor.get_orderbook(command.get('token_id'))
            elif action == 'cancel_order':
                response = executor.cancel_order(command.get('order_id'))
            elif action == 'get_balance':
                response = executor.get_balance()
            elif action == 'ping':
                response = {'success': True, 'message': 'pong'}
            else:
                response = {
                    'success': False,
                    'error': f'Unknown action: {action}'
                }
            
            # Write response to stdout as JSON
            print(json.dumps(response), flush=True)
            
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON: {e}")
            error_response = {
                'success': False,
                'error': f'Invalid JSON: {str(e)}'
            }
            print(json.dumps(error_response), flush=True)
            
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            error_response = {
                'success': False,
                'error': str(e)
            }
            print(json.dumps(error_response), flush=True)


if __name__ == '__main__':
    main()
